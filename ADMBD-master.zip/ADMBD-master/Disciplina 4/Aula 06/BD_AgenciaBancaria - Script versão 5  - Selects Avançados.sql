#Script BD_AgenciaBancaria - Versão 5.0
create database BD_Banco_v5;
use BD_Banco_v5;

create table Banco (
cod_ban int primary key not null auto_increment,
nome_ban varchar (200) not null
);

insert into Banco values (null, 'Caixa Econômica Federal');
insert into Banco values (null, 'Banco do Brasil');

create table Agencia (
cod_ag int primary key not null auto_increment,
numero_ag varchar (100) not null,
nome_ag varchar (100),
telefone_ag varchar (200),
cod_ban_fk int not null,
foreign key (cod_ban_fk) references Banco (cod_ban)
);

insert into Agencia values (null, '0951-2', 'Centro', '69 3421 1111', 2);
insert into Agencia values (null, '4402-1', 'Centro', '69 3422 2299', 2);
insert into Agencia values (null, '1824', 'Centro', '69 3423 1925', 1);
insert into Agencia values (null, '1920', 'Nova Brasilia', '69 3421 1122', 1);


create table Cliente (
cod_cli int primary key not null auto_increment,
nome_cli varchar (200) not null,
cpf_cli varchar (50) not null,
rg_cli varchar (100) not null,
sexo_cli varchar (1),
dataNasc_cli date not null,
renda_cli float not null,
endereco_cli varchar (300) not null,
email_cli varchar (300) not null,
telefone_cli varchar (200) not null
);

insert into Cliente values (null, 'Maria da Silva', '123.123.123-23', '1113322 sesdec/RO', 'F', '1990-10-10', 2500.00, 'Rua das Flores', 'maria.silva@hotmail.com', '3423 3333'); 
insert into Cliente values (null, 'Roberto Carlos', '789.789.789-89', '889977 sesdec/RO', 'M', '1975-01-10', 4990.00, 'Av. Costa', 'roberto.carlos@gmail.com', '8444 8899'); 
insert into Cliente values (null, 'Jane Pereira', '444.666.444-44', '005548 sesdec/RO', 'F', '1989-06-07', 1850.50, 'Rua Presidente', 'jane.pereira@hotmail.com', '9977 8899'); 
insert into Cliente values (null, 'Clodoaldo Bragança', '654.456.654-65', '654658 sesdec/RO', 'F', '1991-10-12', 9850.50, 'Av. Brasil', 'clodoaldo.bragança@gmail.com', '3423 5500'); 
insert into Cliente values (null, 'Livia de Souza', '333.444.666-98', '0033333 sesdec/RO', 'F', '1982-01-30', 1100.00, 'Av. Ji-Parana', 'livia.souza@hotmail.com', '8498 9898'); 
insert into Cliente values (null, 'Joab da Silva', '159.425.456-77', '001215 sesdec/RO', 'M', '2000-10-01', 4990.00, 'Av. Ji-Parana', 'joab.silva@hotmail.com', '69 8411 2321');
insert into cliente values (null, 'Rodrigo Hilbert', '123.445.888-99', '5592 sesdec', 'M', '1970-09-30', 2500.00, 'Rua Dr. Luiz', 'rodrigo.hilbert@yahoo.com.br', '9944 4545');
insert into cliente values (null, 'João Eujácio Teixeira Júnior', '999.445.789-99', '978999992 sesdec', 'M', '1989-01-10', 6000.00, 'Rua Silva Abreu', 'joao.eujacio@ifro.edu.br', '3421 1159');
insert into cliente values (null, 'Everton Feline', '123.123.888-99', '12392 sesdec', 'M', '1987-12-10', 11500.00, 'Rua Alencar Vieira', 'everton.feline@gmail.com','69 84228811');
insert into cliente values (null, 'Igor de Souza Santos', '123.345.848-99', '43299892 sesdec', 'M', '1990-12-30', 1000.00, 'Av. Brasil', 'igor.souza@gmail.com', '69 9977 7777');
insert into cliente values (null, 'Francisco Bezerra', '888.123.111-11', '213156 sesdec', 'M', '1965-01-30', 3500.00, 'Rua Fim do Mundo', 'francisco.bezerra@ifro.edu.br', '69 3423 5502');


create table Conta_Corrente (
cod_cc int primary key not null auto_increment,
numero_cc int not null,
dataAbertura_cc date not null,
saldo_cc float not null,
valorLimite_cc float not null,
saldoComLimite_cc float not null,
cod_ag_fk int not null,
cod_cli_fk int not null,
foreign key (cod_ag_fk) references Agencia (cod_ag),
foreign key (cod_cli_fk) references Cliente (cod_cli)
);


insert into Conta_Corrente values (null, 40650, '2009-01-01', 1232.00, 100.00, 1332.00, 1, 1);
insert into Conta_Corrente values (null, 41897, '2009-01-30', 4564.00, 200.00, 4764.00, 1, 2);
insert into Conta_Corrente values (null, 42487, '2010-06-06', 2211.00, 200.00, 2411.00, 1, 3);
insert into Conta_Corrente values (null, 43456, '2011-04-21', 15.00, 100.00, 115.00, 1, 4);
insert into Conta_Corrente values (null, 44787, '2012-12-31', 0.00, 100.00, 100.00, 1, 5);
insert into Conta_Corrente values (null, 45650, '2013-01-01', 545.00, 100.00, 645.00, 1, 6);
insert into Conta_Corrente values (null, 46897, '2014-01-30', 12345.00, 300.00, 12645.00, 1, 7);
insert into Conta_Corrente values (null, 47487, '2014-06-06', 112.00, 200.00, 312.00, 1, 8);
insert into Conta_Corrente values (null, 48456, '2015-04-21', 10.00, 100.00, 110.00, 1, 9);
insert into Conta_Corrente values (null, 280541, '2016-12-31', 12345.00, 100.00, 12445.00, 3, 10);
insert into Conta_Corrente values (null, 280191, '2016-12-31', 555465.00, 100.00, 555565.00, 3, 11);

create table Deposito (
cod_dep int primary key not null auto_increment,
valor_dep float not null,
data_dep date not null,
tipo_dep varchar (100),
cod_cc_fk int not null,
foreign key (cod_cc_fk) references Conta_Corrente (cod_cc)
);

insert into Deposito values (null, 500.00, '2011-03-21', 'Dinheiro', 1);
insert into Deposito values (null, 50.00, '2011-10-09', 'Dinheiro', 4);
insert into Deposito values (null, 1500.00, '2011-12-20', 'Cheque', 3);
insert into Deposito values (null, 125.00, '2011-06-11', 'Dinheiro', 5);
insert into Deposito values (null, 490.00, '2012-12-02', 'Dinheiro', 2);
insert into Deposito values (null, 1010.00, '2012-12-11', 'Cheque', 6);
insert into Deposito values (null, 120.00, '2016-01-30', 'Dinheiro', 7);
insert into Deposito values (null, 550.00, '2016-06-30', 'Dinheiro', 9);
insert into Deposito values (null, 80.00, '2016-10-23', 'Dinheiro', 10);
insert into Deposito values (null, 1000.00, '2016-11-08', 'Cheque', 10);


create table Saque (
cod_saq int primary key not null auto_increment,
valor_saq float not null,
data_saq date not null,
local_saq varchar (100) not null,
hora_saq time,
cod_cc_fk int not null,
foreign key (cod_cc_fk) references Conta_Corrente (cod_cc)
);

insert into Saque values (null, 100.00, '2014-11-12', 'Caixa Eletrônico', sysdate(), 5);
insert into Saque values (null, 200.00, '2014-12-11', 'Agência', sysdate(), 1);
insert into Saque values (null, 120.00, '2015-12-02', 'Caixa Eletrônico', sysdate(), 2);
insert into Saque values (null, 100.00, '2015-01-03', 'Caixa Eletrônico', sysdate(), 5);
insert into Saque values (null, 200.00, '2015-01-30', 'Caixa Eletrônico', sysdate(), 1);
insert into Saque values (null, 120.00, '2015-02-25', 'Agência', sysdate(), 6);
insert into Saque values (null, 100.00, '2016-01-07', 'Agência', sysdate(), 1);
insert into Saque values (null, 200.00, '2016-01-08', 'Caixa Eletrônico', sysdate(), 4);
insert into Saque values (null, 120.00, '2016-03-20', 'Caixa Eletrônico', sysdate(), 2);
insert into Saque values (null, 100.00, '2016-03-23', 'Agência', sysdate(), 7);
insert into Saque values (null, 200.00, '2016-05-09', 'Caixa Eletrônico', sysdate(), 4);
insert into Saque values (null, 120.00, '2016-06-16', 'Agência', sysdate(), 6);
insert into Saque values (null, 100.00, '2016-08-21', 'Caixa Eletrônico', sysdate(), 9);
insert into Saque values (null, 200.00, '2016-09-06', 'Caixa Eletrônico',sysdate(), 8);
insert into Saque values (null, 120.00, '2016-10-20', 'Caixa Eletrônico', sysdate(), 10);
insert into Saque values (null, 122.22, '2016-10-20', 'Agência', sysdate(), 2);


create table Transferencia (
cod_trans int primary key not null auto_increment,
valor_trans float not null,
data_trans date not null,
descricao_trans varchar (100),
cod_cc_origem_fk int not null,
cod_cc_destino_fk int not null,
foreign key (cod_cc_origem_fk) references Conta_Corrente (cod_cc),
foreign key (cod_cc_destino_fk) references Conta_Corrente (cod_cc)
);

insert into Transferencia values (null, 5100.00, '2010-01-01', 'Pagamento Pensão', 4, 1);
insert into Transferencia values (null, 150.00, '2011-09-20', 'Compra Moto', 2, 3);
insert into Transferencia values (null, 50.00, '2013-10-23', 'Pagamento Divida', 3, 1);
insert into Transferencia values (null, 1000.00, '2014-12-29', 'Mesada Filho', 10, 3);
insert into Transferencia values (null, 660.00, '2016-11-30', 'Divida Banco', 1, 9);
insert into Transferencia values (null, 340.00, '2016-10-10', 'Pagamento', 7, 6);


create table Pagamento (
cod_pag int primary key not null auto_increment,
valor_pag float not null,
data_pag date not null,
tipo_pag varchar (100),
dataVencimento_pag date not null,
codigoBarras_pag varchar (300),
cod_cc_fk int not null,
foreign key (cod_cc_fk) references Conta_Corrente (cod_cc)
);

insert into Pagamento values (null, 300.00, '2015-10-20', 'Boleto', '2015-10-20', '1212312111131', 1);
insert into Pagamento values (null, 54.00, '2015-01-20', 'Convênio', '2015-01-20', '787987987987', 2);
insert into Pagamento values (null, 89.00, '2016-06-20', 'Boleto', '2016-06-22', '6544678979', 1);
insert into Pagamento values (null, 321.00, '2016-10-20', 'Convênio', '2016-10-20', '156546465454', 2);
insert into Pagamento values (null, 123.00, '2016-11-08', 'Boleto', '2016-11-09', '132131564587', 1);

#		EXERCICIOS

#1.		Selecione todos os registros da Conta Corrente substituindo as chaves estrangeiras 
#		(FK) pelo número da Agência e o nome do Cliente sucessivamente. Salve a consulta em uma Visão.
create view dados_conta_corrente as
select 
conta_corrente.cod_cc as Codigo,
conta_corrente.numero_cc as Numero,
conta_corrente.dataAbertura_cc as Data_Abertura,
conta_corrente.saldo_cc as Saldo,
conta_corrente.valorlimite_cc as Valor_Limite,
conta_corrente.saldocomlimite_cc as Saldo_Com_Limite,
agencia.numero_ag as Numero_Agencia,
agencia.nome_ag as Nome_Agencia,
agencia.telefone_ag as Telefone_Agencia,
cliente.nome_cli as Nome_Cliente,
cliente.telefone_cli as Telefone_Cliente
from conta_corrente
inner join agencia on(conta_corrente.cod_ag_fk = agencia.cod_ag)
inner join cliente on(conta_corrente.cod_cli_fk = cliente.cod_cli);

select * from dados_conta_corrente;

#2.		Selecione todos os registros da Transferência substituindo as FK de Conta Corrente 
#		por número e saldo da Conta, e mostre também os nomes dos Cliente de origem e destino. Salve a consulta em uma Visão.

create view dados_transferencias as
select
transferencia.cod_trans as Codigo,
transferencia.valor_trans as Valor,
transferencia.data_trans as Data,
transferencia.descricao_trans as Descricao,
(select numero from dados_conta_corrente where (dados_conta_corrente.codigo = transferencia.cod_cc_origem_fk)) as Numero_CC_Origem,
(select saldo from dados_conta_corrente where (dados_conta_corrente.codigo = transferencia.cod_cc_origem_fk)) as Saldo_CC_Origem,
(select nome_cliente from dados_conta_corrente where (dados_conta_corrente.codigo = transferencia.cod_cc_origem_fk)) as Cliente_Origem,
(select numero from dados_conta_corrente where (dados_conta_corrente.codigo = transferencia.cod_cc_destino_fk)) as Numero_CC_Destino,
(select saldo from dados_conta_corrente where (dados_conta_corrente.codigo = transferencia.cod_cc_destino_fk)) as Saldo_CC_Destino,
(select nome_cliente from dados_conta_corrente where (dados_conta_corrente.codigo = transferencia.cod_cc_destino_fk)) as Cliente_Destino
from transferencia, dados_conta_corrente 
where (transferencia.cod_cc_origem_fk = dados_conta_corrente.codigo);

select * from transferencia;

#------------------------CORREÇÃO---------------------

select
transferencia.cod_trans as Codigo,
transferencia.valor_trans as Valor,
transferencia.data_trans as Data,
transferencia.descricao_trans as Descricao,
cc_o.numero as Numero_CC_Origem,
cc_o.saldo as Saldo_CC_Origem,
cc_o.nome_cliente as Cliente_Origem,
cc_d.numero as Numero_CC_Destino,
cc_d.saldo as Saldo_CC_Destino,
cc_d.nome_cliente as Cliente_Destino
from transferencia
inner join 
dados_conta_corrente as cc_o on 
(transferencia.cod_cc_origem_fk = cc_o.codigo)
inner join 
dados_conta_corrente as cc_d on 
(transferencia.cod_cc_destino_fk = cc_d.codigo);
#3.		Selecione todos os registros do Saque substituindo as FK de Conta Corrente por número
#		e saldo da Conta, e mostre também o nome do Cliente. Salve a consulta em uma Visão.

create view dados_saque as
select
saque.cod_saq as Codigo,
saque.valor_saq as Valor,
saque.data_saq as Data,
saque.local_saq as Local,
saque.hora_saq as Hora,
dados_conta_corrente.numero as Numero_CC_,
dados_conta_corrente.saldo as Saldo_CC,
dados_conta_corrente.nome_cliente as Cliente
from saque 
left join dados_conta_corrente on (saque.cod_cc_fk = dados_conta_corrente.codigo);

select * from dados_saque;

#4.		Selecione todos os registros do Depósito substituindo as FK de Conta Corrente por 
#		número e saldo da Conta, e mostre também o nome do Cliente. Salve a consulta em uma Visão.

select * from deposito;

create view dados_deposito as
select 
deposito.cod_dep as Codigo,
deposito.valor_dep as Valor,
deposito.data_dep as Data,
deposito.tipo_dep as Tipo,
dados_conta_corrente.numero as Numero_CC,
dados_conta_corrente.saldo as Saldo_CC,
dados_conta_corrente.nome_cliente as Cliente_CC
from deposito 
left join dados_conta_corrente on (deposito.cod_cc_fk = dados_conta_corrente.codigo);

select * from dados_deposito;

#5.		Selecione todos os registros do Pagamento substituindo as FK de Conta Corrente por 
#		número e saldo da Conta, e mostre também o nome do Cliente. Salve a consulta em uma Visão.

select * from pagamento;

create view dados_pagamento as
select 
pagamento.cod_pag as Codigo,
pagamento.valor_pag as Valor,
pagamento.data_pag as Data,
pagamento.tipo_pag as Tipo,
pagamento.datavencimento_pag as Data_Vencimento,
pagamento.codigobarras_pag as Codigo_Barras,
dados_conta_corrente.numero as Numero_CC,
dados_conta_corrente.saldo as Saldo_CC,
dados_conta_corrente.nome_cliente as Cliente
from pagamento
inner join dados_conta_corrente on (pagamento.cod_cc_fk = dados_conta_corrente.codigo);

select * from dados_pagamento;
#6.		Selecione o código e nome do Cliente, informando o nome do seu Banco. 
#		Salve a consulta em uma Visão.

select * from cliente;
select * from banco;
select * from agencia;
select * from conta_corrente;

create view dados_cliente_banco as
select 
cliente.cod_cli as Codigo,
cliente.nome_cli as Nome,
banco.nome_ban as Banco
from cliente
inner join conta_corrente on (conta_corrente.cod_cli_fk = cliente.cod_cli)
inner join agencia on (conta_corrente.cod_ag_fk = agencia.cod_ag)
inner join banco on (banco.cod_ban = agencia.cod_ban_fk);

select * from dados_cliente_banco;

#7.		Selecione o nome do Banco, o número da Agência, o nome do Cliente, o número e o 
#		saldo da sua Conta Corrente. Salve a consulta em uma Visão.


select * from cliente;
select * from banco;
select * from agencia;
select * from conta_corrente;

create view dados_banco_clientes as
select
banco.nome_ban as Banco,
agencia.numero_ag as Agencia,
conta_corrente.numero_cc as Conta_Corrente,
cliente.nome_cli as Cliente,
conta_corrente.saldo_cc as Saldo
from conta_corrente
inner join agencia on (agencia.cod_ag = conta_corrente.cod_ag_fk)
inner join cliente on (cliente.cod_cli = conta_corrente.cod_cli_fk)
inner join banco on (agencia.cod_ban_fk = banco.cod_ban);

select * from dados_banco_clientes;

#8.		Selecione o nome do Cliente, número da Conta Corrente, a soma, a média, o valor máximo, 
#		o valor mínimo e a quantidade de Saques realizados. Salve a consulta em uma Visão.

select * from cliente;
select * from saque;
select * from conta_corrente;
drop view dados_saque;

create view dados_saque as
select 
cliente.nome_cli as Nome,
conta_corrente.numero_cc as Conta_Corrente,
(select sum(valor_saq) from saque where(saque.cod_cc_fk = conta_corrente.cod_cc)) as Soma_Saques,
(select avg(valor_saq) from saque where(saque.cod_cc_fk = conta_corrente.cod_cc)) as Media_Saques,
(select max(valor_saq) from saque where(saque.cod_cc_fk = conta_corrente.cod_cc)) as Valor_Max_Saques,
(select min(valor_saq) from saque where(saque.cod_cc_fk = conta_corrente.cod_cc)) as Valor_Min_Saques,
(select count(cod_saq) from saque where(saque.cod_cc_fk = conta_corrente.cod_cc)) as Quantidade_Saques
from conta_corrente
inner join cliente on (cliente.cod_cli = conta_corrente.cod_cli_fk);

select * from dados_saque;

#9.		Selecione o nome do Cliente, número da Conta Corrente, a soma, a média, o valor máximo, 
#		o valor mínimo e a quantidade de Depósitos realizados. Salve a consulta em uma Visão.
select * from deposito;

create view dados_deposito as
select 
cliente.nome_cli as Nome,
conta_corrente.numero_cc as Conta_Corrente,
(select sum(valor_dep) from deposito where(deposito.cod_cc_fk = conta_corrente.cod_cc)) as Soma_Depositos,
(select avg(valor_dep) from deposito where(deposito.cod_cc_fk = conta_corrente.cod_cc)) as Media_Depositos,
(select max(valor_dep) from deposito where(deposito.cod_cc_fk = conta_corrente.cod_cc)) as Valor_Max_Depositos,
(select min(valor_dep) from deposito where(deposito.cod_cc_fk = conta_corrente.cod_cc)) as Valor_Min_Depositos,
(select count(cod_dep) from deposito where(deposito.cod_cc_fk = conta_corrente.cod_cc)) as Quantidade_Depositos
from conta_corrente
inner join cliente on (cliente.cod_cli = conta_corrente.cod_cli_fk);

select * from dados_deposito;


#10.	Selecione o nome do Cliente, número da Conta Corrente, a soma, a média, o valor máximo, 
#		o valor mínimo e a quantidade de Pagamentos realizados. Salve a consulta em uma Visão.

select * from pagamento;

create view dados_pagamento_cliente as
select 
cliente.nome_cli as Nome,
conta_corrente.numero_cc as Conta_Corrente,
(select sum(valor_pag) from pagamento where(pagamento.cod_cc_fk = conta_corrente.cod_cc)) as Soma_Pagamentos,
(select avg(valor_pag) from pagamento where(pagamento.cod_cc_fk = conta_corrente.cod_cc)) as Media_Pagamentos,
(select max(valor_pag) from pagamento where(pagamento.cod_cc_fk = conta_corrente.cod_cc)) as Valor_Max_Pagamentos,
(select min(valor_pag) from pagamento where(pagamento.cod_cc_fk = conta_corrente.cod_cc)) as Valor_Min_Pagamentos,
(select count(cod_pag) from pagamento where(pagamento.cod_cc_fk = conta_corrente.cod_cc)) as Quantidade_Pagamentos
from conta_corrente
inner join cliente on (cliente.cod_cli = conta_corrente.cod_cli_fk);


select * from dados_pagamento_cliente;




