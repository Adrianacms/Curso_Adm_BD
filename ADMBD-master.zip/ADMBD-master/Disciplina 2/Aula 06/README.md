# Atividade:

## Analise o caso a seguir:

"Você é o DBA em uma empresa de desenvolvimento de software e recebeu a tarefa de modelar o sistema de um cliente, a Escola de Informática Aprende Mais. Essa escola precisa automatizar os seus processos, que envolvem a matricula dos alunos nas disciplinas dos cursos de informática oferecidos pela escola. Também espera-se que o sistema controle as turmas de cada disciplina, gerenciando qual o professor da disciplina e local e horário da turma. Por fim o sistema precisa controlar os diários de cada turma, armazenando informações como a presença nas aulas dos alunos e as notas deles em cada disciplina."

## Meu Diagrama ER

![Meu diagrama ER](https://raw.githubusercontent.com/castelogui/ADMBD/master/Disciplina%202/Aula%2006/Aula%2006%20-%20Escola%20de%20Inform%C3%A1tica%20Aprende%20Mais.jpg)