# Atividade:

## Analise o caso a seguir:

"Você é o DBA em uma empresa de desenvolvimento de software e recebeu a tarefa de modelar o sistema de um cliente, o **Supermercado Vende Mais**. Este supermercado precisa automatizar os seus processos através deste novo sistema, entre eles o processo de vender os seus produtos para os clientes, comprar produtos dos fornecedores para reposição do estoque, controlar o financeiro do supermercado a fim de saber tudo que é recebido nas vendas e pago de despesas do estabelecimento comercial. Além de armazenar dados relevantes sobre o negócio como funcionários envolvidos nos processos, setores, controle de caixa, entre outros. Além disso, espera-se que o sistema controle as entregas a domicílio, processo implementado este ano devida a pandemia."

---

## Meu Diagrama ER

![Minha ativida](https://raw.githubusercontent.com/castelogui/ADMBD/master/Disciplina%202/Aula%2005/Aula%2005%20-%20Supermercado%20Vende%20Mais.jpg)
